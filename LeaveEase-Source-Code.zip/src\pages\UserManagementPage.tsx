import { useState } from 'react';
import { useApp } from '@/store/AppContext';
import { Card, CardHeader } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button, EmptyState, Field, Input, Select } from '@/components/ui/Form';
import { SearchBar } from '@/components/layout/Topbar';
import { Modal, ConfirmDialog } from '@/components/ui/Modal';
import { toCSV, downloadCSV } from '@/lib/utils';
import { Users, Plus, Edit, Trash2, Download, GraduationCap, BookOpen, Building2, ShieldCheck } from 'lucide-react';
import type { User, Role } from '@/types';

const roleLabels: Record<Role, string> = {
  student: 'Student', teacher: 'Teacher', hod: 'HOD', admin: 'Admin',
};

const roleIcons: Record<Role, React.ReactNode> = {
  student: <GraduationCap size={14} />, teacher: <BookOpen size={14} />,
  hod: <Building2 size={14} />, admin: <ShieldCheck size={14} />,
};

const roleVariants: Record<Role, 'navy' | 'blue' | 'success' | 'warning' | 'neutral'> = {
  student: 'navy', teacher: 'blue', hod: 'success', admin: 'warning',
};

const departments = ['Computer Science', 'Electronics', 'Mechanical', 'Civil', 'Electrical', 'Information Technology', 'Administration'];

export function UserManagementPage() {
  const { data, addUser, updateUser, deleteUser } = useApp();
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | Role>('all');
  const [showForm, setShowForm] = useState(false);
  const [editUser, setEditUser] = useState<User | null>(null);
  const [deleteUserId, setDeleteUserId] = useState<string | null>(null);
  const [form, setForm] = useState({ name: '', email: '', role: 'student' as Role, department: 'Computer Science', year: 1, rollNo: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const filtered = data.users
    .filter((u) => roleFilter === 'all' || u.role === roleFilter)
    .filter((u) => {
      const q = search.toLowerCase();
      return u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) ||
        (u.rollNo || '').toLowerCase().includes(q) || u.department.toLowerCase().includes(q);
    });

  const roleCounts: Record<string, number> = {
    student: data.users.filter((u) => u.role === 'student').length,
    teacher: data.users.filter((u) => u.role === 'teacher').length,
    hod: data.users.filter((u) => u.role === 'hod').length,
    admin: data.users.filter((u) => u.role === 'admin').length,
  };

  const openAdd = () => {
    setForm({ name: '', email: '', role: 'student', department: 'Computer Science', year: 1, rollNo: '' });
    setEditUser(null);
    setErrors({});
    setShowForm(true);
  };

  const openEdit = (u: User) => {
    setForm({ name: u.name, email: u.email, role: u.role, department: u.department, year: u.year || 1, rollNo: u.rollNo || '' });
    setEditUser(u);
    setErrors({});
    setShowForm(true);
  };

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Name is required';
    if (!form.email.trim()) e.email = 'Email is required';
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Invalid email format';
    if (form.role === 'student' && !form.rollNo.trim()) e.rollNo = 'Roll number is required for students';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = () => {
    if (!validate()) return;
    const userData = {
      name: form.name.trim(),
      email: form.email.trim(),
      role: form.role,
      department: form.department,
      ...(form.role === 'student' ? { year: form.year, rollNo: form.rollNo.trim() } : {}),
    };
    if (editUser) {
      updateUser(editUser.id, userData);
    } else {
      addUser(userData);
    }
    setShowForm(false);
  };

  const exportCSV = () => {
    const rows = filtered.map((u) => ({
      Name: u.name, Email: u.email, Role: roleLabels[u.role],
      Department: u.department, Year: u.year || '', RollNo: u.rollNo || '',
    }));
    downloadCSV('users.csv', toCSV(rows));
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Role summary cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {(['student', 'teacher', 'hod', 'admin'] as Role[]).map((r) => (
          <div key={r} className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-navy-50 text-navy-700">
                {roleIcons[r]}
              </div>
              <div>
                <p className="text-sm text-gray-500">{roleLabels[r]}s</p>
                <p className="text-xl font-bold text-navy-900">{roleCounts[r]}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Controls */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex-1 max-w-md">
          <SearchBar value={search} onChange={setSearch} placeholder="Search by name, email, roll no..." />
        </div>
        <div className="flex items-center gap-2">
          <Select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value as 'all' | Role)} className="w-auto">
            <option value="all">All Roles</option>
            <option value="student">Students</option>
            <option value="teacher">Teachers</option>
            <option value="hod">HODs</option>
            <option value="admin">Admins</option>
          </Select>
          <Button variant="secondary" size="sm" onClick={exportCSV}><Download size={16} /> CSV</Button>
          <Button size="sm" onClick={openAdd}><Plus size={16} /> Add User</Button>
        </div>
      </div>

      {/* Users table */}
      <Card>
        <CardHeader title="User Management" subtitle={`${filtered.length} user(s)`} />
        {filtered.length === 0 ? (
          <EmptyState icon={<Users size={32} />} title="No users found" message="No users match your search" />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 text-left text-xs font-semibold uppercase tracking-wider text-gray-500">
                  <th className="px-5 py-3">Name</th>
                  <th className="px-5 py-3">Email</th>
                  <th className="px-5 py-3">Role</th>
                  <th className="px-5 py-3">Department</th>
                  <th className="px-5 py-3">Roll No</th>
                  <th className="px-5 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((u) => (
                  <tr key={u.id} className="border-b border-gray-50 hover:bg-gray-50">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-navy-100 text-xs font-bold text-navy-700">
                          {u.name.charAt(0)}
                        </div>
                        <span className="font-medium text-gray-800">{u.name}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3 text-gray-600">{u.email}</td>
                    <td className="px-5 py-3">
                      <Badge variant={roleVariants[u.role]}>{roleIcons[u.role]} {roleLabels[u.role]}</Badge>
                    </td>
                    <td className="px-5 py-3 text-gray-600">{u.department}</td>
                    <td className="px-5 py-3 text-gray-600">{u.rollNo || '—'}</td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-1">
                        <button onClick={() => openEdit(u)} className="rounded-lg p-1.5 text-navy-600 hover:bg-navy-50">
                          <Edit size={18} />
                        </button>
                        <button onClick={() => setDeleteUserId(u.id)} className="rounded-lg p-1.5 text-red-600 hover:bg-red-50">
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Add/Edit user modal */}
      <Modal
        open={showForm}
        title={editUser ? 'Edit User' : 'Add User'}
        onClose={() => setShowForm(false)}
        footer={
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setShowForm(false)}>Cancel</Button>
            <Button onClick={submit}>{editUser ? 'Update' : 'Add User'}</Button>
          </div>
        }
      >
        <div className="space-y-4">
          <Field label="Full Name" required error={errors.name}>
            <Input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="e.g. John Doe" />
          </Field>
          <Field label="Email" required error={errors.email}>
            <Input type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} placeholder="e.g. john@college.edu" />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Role" required>
              <Select value={form.role} onChange={(e) => setForm((f) => ({ ...f, role: e.target.value as Role }))}>
                <option value="student">Student</option>
                <option value="teacher">Teacher</option>
                <option value="hod">HOD</option>
                <option value="admin">Admin</option>
              </Select>
            </Field>
            <Field label="Department" required>
              <Select value={form.department} onChange={(e) => setForm((f) => ({ ...f, department: e.target.value }))}>
                {departments.map((d) => <option key={d} value={d}>{d}</option>)}
              </Select>
            </Field>
          </div>
          {form.role === 'student' && (
            <div className="grid grid-cols-2 gap-4">
              <Field label="Year" required>
                <Select value={form.year} onChange={(e) => setForm((f) => ({ ...f, year: Number(e.target.value) }))}>
                  <option value={1}>1st Year</option>
                  <option value={2}>2nd Year</option>
                  <option value={3}>3rd Year</option>
                  <option value={4}>4th Year</option>
                </Select>
              </Field>
              <Field label="Roll Number" required error={errors.rollNo}>
                <Input value={form.rollNo} onChange={(e) => setForm((f) => ({ ...f, rollNo: e.target.value }))} placeholder="e.g. CS21B001" />
              </Field>
            </div>
          )}
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deleteUserId}
        title="Delete User"
        message="This will permanently remove the user. Continue?"
        confirmLabel="Delete"
        variant="danger"
        onConfirm={() => { if (deleteUserId) deleteUser(deleteUserId); setDeleteUserId(null); }}
        onCancel={() => setDeleteUserId(null)}
      />
    </div>
  );
}
