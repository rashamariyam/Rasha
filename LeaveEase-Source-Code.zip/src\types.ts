export type Role = 'student' | 'teacher' | 'hod' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  department: string;
  year?: number;
  rollNo?: string;
}

export type LeaveStatus = 'pending' | 'approved' | 'rejected';

export interface LeaveRequest {
  id: string;
  studentId: string;
  studentName: string;
  rollNo: string;
  department: string;
  leaveType: string;
  startDate: string;
  endDate: string;
  reason: string;
  documentName?: string;
  status: LeaveStatus;
  teacherApproved: boolean;
  hodApproved: boolean;
  createdAt: string;
  decidedBy?: string;
  decidedAt?: string;
  decisionNote?: string;
}

export interface GreenCardSlot {
  id: string;
  title: string;
  date: string;
  startTime: string;
  endTime: string;
  capacity: number;
  bookedIds: string[];
}

export interface Booking {
  id: string;
  slotId: string;
  studentId: string;
  studentName: string;
  bookedAt: string;
}

export interface Classroom {
  id: string;
  roomNumber: string;
  building: string;
  capacity: number;
  floor: number;
}

export interface ClassroomSchedule {
  id: string;
  classroomId: string;
  date: string;
  startTime: string;
  endTime: string;
  purpose: string;
  bookedBy: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  createdAt: string;
}

export type Page =
  | 'dashboard'
  | 'apply-leave'
  | 'leave-history'
  | 'leave-approvals'
  | 'green-card'
  | 'my-bookings'
  | 'classroom'
  | 'users'
  | 'notifications';

export interface AppData {
  users: User[];
  leaveRequests: LeaveRequest[];
  greenCardSlots: GreenCardSlot[];
  bookings: Booking[];
  classrooms: Classroom[];
  classroomSchedules: ClassroomSchedule[];
  notifications: Notification[];
}
