import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type {
  AppData, User, LeaveRequest, GreenCardSlot, Booking,
  Classroom, ClassroomSchedule, Notification, Role, Page,
} from '@/types';
import { loadData, saveData, resetData, uid, isoHoursFromNow } from '@/lib/storage';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
}

interface AppContextValue {
  // Auth
  currentUser: User | null;
  login: (role: Role) => void;
  loginAsUser: (userId: string) => void;
  logout: () => void;

  // Navigation
  page: Page;
  setPage: (p: Page) => void;

  // Data
  data: AppData;

  // Toasts
  toasts: Toast[];
  toast: (type: Toast['type'], message: string) => void;
  dismissToast: (id: string) => void;

  // Leave
  addLeaveRequest: (req: Omit<LeaveRequest, 'id' | 'status' | 'teacherApproved' | 'hodApproved' | 'createdAt'>) => void;
  decideLeave: (id: string, approved: boolean, note: string) => void;

  // Green Card
  addSlot: (slot: Omit<GreenCardSlot, 'id' | 'bookedIds'>) => void;
  updateSlot: (id: string, updates: Partial<GreenCardSlot>) => void;
  deleteSlot: (id: string) => void;
  bookSlot: (slotId: string) => void;
  cancelBooking: (slotId: string) => void;

  // Classrooms
  addClassroom: (c: Omit<Classroom, 'id'>) => void;
  updateClassroom: (id: string, updates: Partial<Classroom>) => void;
  deleteClassroom: (id: string) => void;
  addSchedule: (s: Omit<ClassroomSchedule, 'id'>) => void;
  deleteSchedule: (id: string) => void;

  // Users
  addUser: (u: Omit<User, 'id'>) => void;
  updateUser: (id: string, updates: Partial<User>) => void;
  deleteUser: (id: string) => void;

  // Notifications
  markNotificationRead: (id: string) => void;
  markAllRead: () => void;

  // Reset
  resetAllData: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(() => loadData());
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [page, setPage] = useState<Page>('dashboard');
  const [toasts, setToasts] = useState<Toast[]>([]);

  const update = useCallback((updater: (d: AppData) => AppData) => {
    setData((prev) => {
      const next = updater(prev);
      saveData(next);
      return next;
    });
  }, []);

  const toast = useCallback((type: Toast['type'], message: string) => {
    const id = uid('toast');
    setToasts((t) => [...t, { id, type, message }]);
    setTimeout(() => {
      setToasts((t) => t.filter((x) => x.id !== id));
    }, 4000);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((t) => t.filter((x) => x.id !== id));
  }, []);

  const addNotification = (d: AppData, userId: string, title: string, message: string, type: Notification['type']): AppData => {
    const n: Notification = { id: uid('nt'), userId, title, message, type, read: false, createdAt: isoHoursFromNow(0) };
    return { ...d, notifications: [n, ...d.notifications] };
  };

  // Auth
  const login = useCallback((role: Role) => {
    const user = data.users.find((u) => u.role === role);
    if (user) {
      setCurrentUser(user);
      setPage('dashboard');
    }
  }, [data.users]);

  const loginAsUser = useCallback((userId: string) => {
    const user = data.users.find((u) => u.id === userId);
    if (user) {
      setCurrentUser(user);
      setPage('dashboard');
    }
  }, [data.users]);

  const logout = useCallback(() => {
    setCurrentUser(null);
    setPage('dashboard');
  }, []);

  // Leave
  const addLeaveRequest = useCallback((req: Omit<LeaveRequest, 'id' | 'status' | 'teacherApproved' | 'hodApproved' | 'createdAt'>) => {
    const newReq: LeaveRequest = {
      ...req,
      id: uid('lv'),
      status: 'pending',
      teacherApproved: false,
      hodApproved: false,
      createdAt: isoHoursFromNow(0),
    };
    update((d) => {
      // Notify teachers of same department
      let next = { ...d, leaveRequests: [newReq, ...d.leaveRequests] };
      const teachers = d.users.filter((u) => u.role === 'teacher' && u.department === req.department);
      for (const t of teachers) {
        next = addNotification(next, t.id, 'New Leave Request', `${req.studentName} submitted a ${req.leaveType} request.`, 'info');
      }
      return next;
    });
    toast('success', 'Leave application submitted successfully');
  }, [update, toast]);

  const decideLeave = useCallback((id: string, approved: boolean, note: string) => {
    update((d) => {
      const req = d.leaveRequests.find((r) => r.id === id);
      if (!req) return d;
      const decider = currentUser?.name ?? 'Reviewer';
      let status = req.status;
      let teacherApproved = req.teacherApproved;
      let hodApproved = req.hodApproved;

      if (currentUser?.role === 'teacher') {
        teacherApproved = approved;
        if (!approved) status = 'rejected';
        else if (req.hodApproved) status = 'approved';
        else status = 'pending';
      } else if (currentUser?.role === 'hod') {
        hodApproved = approved;
        if (!approved) status = 'rejected';
        else if (teacherApproved) status = 'approved';
        else status = 'pending';
      }

      const updatedReq: LeaveRequest = {
        ...req, status, teacherApproved, hodApproved,
        decidedBy: decider, decidedAt: isoHoursFromNow(0), decisionNote: note || undefined,
      };
      const next = {
        ...d,
        leaveRequests: d.leaveRequests.map((r) => (r.id === id ? updatedReq : r)),
      };
      const msg = approved
        ? `Your ${req.leaveType} request has been ${status === 'approved' ? 'approved' : 'partially approved'} by ${decider}.`
        : `Your ${req.leaveType} request has been rejected by ${decider}.`;
      return addNotification(next, req.studentId, `Leave ${status === 'rejected' ? 'Rejected' : 'Updated'}`, msg, approved ? 'success' : 'error');
    });
    toast(approved ? 'success' : 'info', `Request ${approved ? 'approved' : 'rejected'}`);
  }, [update, currentUser, toast]);

  // Green Card
  const addSlot = useCallback((slot: Omit<GreenCardSlot, 'id' | 'bookedIds'>) => {
    update((d) => ({ ...d, greenCardSlots: [...d.greenCardSlots, { ...slot, id: uid('gc'), bookedIds: [] }] }));
    toast('success', 'Green Card slot added');
  }, [update, toast]);

  const updateSlot = useCallback((id: string, updates: Partial<GreenCardSlot>) => {
    update((d) => ({ ...d, greenCardSlots: d.greenCardSlots.map((s) => (s.id === id ? { ...s, ...updates } : s)) }));
    toast('success', 'Slot updated');
  }, [update, toast]);

  const deleteSlot = useCallback((id: string) => {
    update((d) => ({
      ...d,
      greenCardSlots: d.greenCardSlots.filter((s) => s.id !== id),
      bookings: d.bookings.filter((b) => b.slotId !== id),
    }));
    toast('info', 'Slot deleted');
  }, [update, toast]);

  const bookSlot = useCallback((slotId: string) => {
    if (!currentUser) return;
    update((d) => {
      const slot = d.greenCardSlots.find((s) => s.id === slotId);
      if (!slot) return d;
      if (slot.bookedIds.includes(currentUser.id)) return d;
      if (slot.bookedIds.length >= slot.capacity) return d;
      const booking: Booking = { id: uid('bk'), slotId, studentId: currentUser.id, studentName: currentUser.name, bookedAt: isoHoursFromNow(0) };
      return {
        ...d,
        greenCardSlots: d.greenCardSlots.map((s) => (s.id === slotId ? { ...s, bookedIds: [...s.bookedIds, currentUser.id] } : s)),
        bookings: [booking, ...d.bookings],
      };
    });
    toast('success', 'Slot booked successfully');
  }, [currentUser, update, toast]);

  const cancelBooking = useCallback((slotId: string) => {
    if (!currentUser) return;
    update((d) => ({
      ...d,
      greenCardSlots: d.greenCardSlots.map((s) => (s.id === slotId ? { ...s, bookedIds: s.bookedIds.filter((id) => id !== currentUser.id) } : s)),
      bookings: d.bookings.filter((b) => !(b.slotId === slotId && b.studentId === currentUser.id)),
    }));
    toast('info', 'Booking cancelled');
  }, [currentUser, update, toast]);

  // Classrooms
  const addClassroom = useCallback((c: Omit<Classroom, 'id'>) => {
    update((d) => ({ ...d, classrooms: [...d.classrooms, { ...c, id: uid('rm') }] }));
    toast('success', 'Classroom added');
  }, [update, toast]);

  const updateClassroom = useCallback((id: string, updates: Partial<Classroom>) => {
    update((d) => ({ ...d, classrooms: d.classrooms.map((c) => (c.id === id ? { ...c, ...updates } : c)) }));
    toast('success', 'Classroom updated');
  }, [update, toast]);

  const deleteClassroom = useCallback((id: string) => {
    update((d) => ({
      ...d,
      classrooms: d.classrooms.filter((c) => c.id !== id),
      classroomSchedules: d.classroomSchedules.filter((s) => s.classroomId !== id),
    }));
    toast('info', 'Classroom deleted');
  }, [update, toast]);

  const addSchedule = useCallback((s: Omit<ClassroomSchedule, 'id'>) => {
    update((d) => ({ ...d, classroomSchedules: [...d.classroomSchedules, { ...s, id: uid('sc') }] }));
    toast('success', 'Schedule added');
  }, [update, toast]);

  const deleteSchedule = useCallback((id: string) => {
    update((d) => ({ ...d, classroomSchedules: d.classroomSchedules.filter((s) => s.id !== id) }));
    toast('info', 'Schedule removed');
  }, [update, toast]);

  // Users
  const addUser = useCallback((u: Omit<User, 'id'>) => {
    update((d) => ({ ...d, users: [...d.users, { ...u, id: uid('u') }] }));
    toast('success', 'User added');
  }, [update, toast]);

  const updateUser = useCallback((id: string, updates: Partial<User>) => {
    update((d) => ({ ...d, users: d.users.map((u) => (u.id === id ? { ...u, ...updates } : u)) }));
    toast('success', 'User updated');
  }, [update, toast]);

  const deleteUser = useCallback((id: string) => {
    update((d) => ({ ...d, users: d.users.filter((u) => u.id !== id) }));
    toast('info', 'User deleted');
  }, [update, toast]);

  // Notifications
  const markNotificationRead = useCallback((id: string) => {
    update((d) => ({ ...d, notifications: d.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)) }));
  }, [update]);

  const markAllRead = useCallback(() => {
    if (!currentUser) return;
    update((d) => ({ ...d, notifications: d.notifications.map((n) => (n.userId === currentUser.id ? { ...n, read: true } : n)) }));
    toast('success', 'All notifications marked as read');
  }, [currentUser, update, toast]);

  const resetAllData = useCallback(() => {
    const fresh = resetData();
    setData(fresh);
    toast('info', 'All data has been reset to defaults');
  }, [toast]);

  const value: AppContextValue = {
    currentUser, login, loginAsUser, logout,
    page, setPage,
    data,
    toasts, toast, dismissToast,
    addLeaveRequest, decideLeave,
    addSlot, updateSlot, deleteSlot, bookSlot, cancelBooking,
    addClassroom, updateClassroom, deleteClassroom, addSchedule, deleteSchedule,
    addUser, updateUser, deleteUser,
    markNotificationRead, markAllRead,
    resetAllData,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
