import { AppProvider, useApp } from '@/store/AppContext';
import { Layout } from '@/components/layout/Layout';
import { ToastContainer } from '@/components/ui/Toast';
import { LoginPage } from '@/pages/LoginPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { ApplyLeavePage } from '@/pages/ApplyLeavePage';
import { LeaveHistoryPage } from '@/pages/LeaveHistoryPage';
import { LeaveApprovalsPage } from '@/pages/LeaveApprovalsPage';
import { GreenCardPage } from '@/pages/GreenCardPage';
import { MyBookingsPage } from '@/pages/MyBookingsPage';
import { ClassroomPage } from '@/pages/ClassroomPage';
import { UserManagementPage } from '@/pages/UserManagementPage';
import { NotificationsPage } from '@/pages/NotificationsPage';
import type { Page } from '@/types';

const pageMap: Record<Page, React.ComponentType> = {
  'dashboard': DashboardPage,
  'apply-leave': ApplyLeavePage,
  'leave-history': LeaveHistoryPage,
  'leave-approvals': LeaveApprovalsPage,
  'green-card': GreenCardPage,
  'my-bookings': MyBookingsPage,
  'classroom': ClassroomPage,
  'users': UserManagementPage,
  'notifications': NotificationsPage,
};

function AppContent() {
  const { currentUser, page } = useApp();

  if (!currentUser) {
    return (
      <>
        <LoginPage />
        <ToastContainer />
      </>
    );
  }

  const PageComponent = pageMap[page] || DashboardPage;

  return (
    <>
      <Layout>
        <PageComponent />
      </Layout>
      <ToastContainer />
    </>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;
